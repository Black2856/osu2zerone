作成者 : @Black2856

Osu!maniaの譜面を
ZERONEIIIのプロジェクトの譜面に変換するアプリケーションです

プロジェクト内ではsongdataリスト内に譜面データがありますので書き出しで落としてから
追加して読み込ませるのが良いかと思います。

ZERONEIII by ZVA6
https://scratch.mit.edu/projects/388537072/

使用する場合はクレジットの記載をして頂けると幸いです。
※二次配布禁止